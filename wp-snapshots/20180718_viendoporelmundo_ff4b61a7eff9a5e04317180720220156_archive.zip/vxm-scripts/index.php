<?php
    // silence is golden
?>